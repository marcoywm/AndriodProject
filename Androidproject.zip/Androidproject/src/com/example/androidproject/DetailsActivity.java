package com.example.androidproject;

import java.util.List;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.GetDataCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import android.R.string;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailsActivity extends Activity {
	
	//for the online product number
	int num=0;
	ParseObject product1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_details);
		
        Intent intent = getIntent();
		
		//get title
		String proId = intent.getExtras().getString("proId");
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery("product");
		 
		// Retrieve the object by id
		query.getInBackground(proId, new GetCallback<ParseObject>() {
		  public void done(final ParseObject product, ParseException e) {
		    if (e == null) {
		    	
		    	product1=product;
		    	//display title
		    	TextView TvTitle = (TextView) findViewById(R.id.tvName);
				TvTitle.setText(product.getString("Name"));
				
				//display des
		    	TextView Tvdes = (TextView) findViewById(R.id.tvDes);
		    	Tvdes.setText(product.getString("description"));
		    	
		    
		    	//display price
		    	TextView TvPrice = (TextView) findViewById(R.id.tvPrice);
		    	TvPrice.setText("Price: $"+String.valueOf(product.getDouble("price")));
		    	
		    	
		    	ParseFile imagefile = (ParseFile)product.get("productImage");
				
	    		
	        	 imagefile.getDataInBackground(new GetDataCallback() {
				  public void done(byte[] data, ParseException e) {
				    if (e == null) {
				    	
				  
				   ImageView imgView = (ImageView)findViewById(R.id.imageView1); 	
				   Bitmap btmap=BitmapFactory.decodeByteArray(data, 0, data.length);
				   
				   imgView.setImageBitmap(btmap);
				   
				   Button  btnAdd=(Button) findViewById(R.id.btnAdd);
				   
				   
				   btnAdd.setOnClickListener(new OnClickListener() {
			        	public void onClick(View arg0) {
			        		num++;
			        		 
			        		String ordr ="You purchase "+" "+String.valueOf(num)+" "+product.getString("Name");
			        		Toast.makeText(DetailsActivity.this, ordr, 50000).show();
			        		
			        		
			        	}
			        });
				
				 
				    	
				      // data has the bytes for the resume
				    } else {
				      // something went wrong
				    	Toast.makeText(DetailsActivity.this, "fails", 50000).show();
				    }
				  }
				});
	        	 
	        		 
		    	
		    }
		  }

		
		});

	}
	
	
	@Override
	public void onBackPressed(){
		
		  if(num>0)
		{
			  final ParseObject linePro=new ParseObject("lineProduct");
			  
			  linePro.put("number",num);
			  linePro.put("product",product1);
			  double proTotal=product1.getDouble("price")*num;
			  linePro.put("total", proTotal);
			  String name=product1.getString("Name");
			  linePro.put("proName", name);
			  ParseUser currentUser = ParseUser.getCurrentUser();
			  
			  ParseQuery<ParseObject> query = ParseQuery.getQuery("order");
				query.whereEqualTo("parent", currentUser);
				query.findInBackground(new FindCallback<ParseObject>() {
				    public void done(List<ParseObject> orderList, ParseException e) {
				    	if (e==null){
				    		
				    		//int i=orderList.size()-1;
				    		ParseObject order=orderList.get(0);
				    		//double total=order.getDouble("total");
				    		linePro.put("order",order);
				    		linePro.saveInBackground();
				    		finish();
				    	
				    	}
				    	else
				    	{
				    		// something went wrong
					    	Toast.makeText(DetailsActivity.this, "fails", 50000).show();
					    	
				    	}
				    	
				    }
				
		});
		}
		  else
		  { 
			  finish();
		  }
	
	}
       
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.details, menu);
		return true;
	}

}
