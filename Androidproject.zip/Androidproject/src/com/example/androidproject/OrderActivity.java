package com.example.androidproject;

import java.util.List;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class OrderActivity extends Activity {

	ParseUser currentUser;
	String orderId="";
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_order);
		
		 currentUser = ParseUser.getCurrentUser();
		
		if (currentUser != null) {
			  // do stuff with the user;
				TextView tv_wel=(TextView) findViewById(R.id.tvOrdWel);
				
				tv_wel.setText("Welcome "+currentUser.getUsername());
				
				 ParseQuery<ParseObject> query = ParseQuery.getQuery("order");
				 query.whereEqualTo("parent", currentUser);
				 query.findInBackground(new FindCallback<ParseObject>() {
					    public void done(List<ParseObject> orderList, ParseException e) {
					    	if (e==null){
					    		
					    		
					    		//int i=orderList.size()-1;
					    		final ParseObject order=orderList.get(0);
					    		orderId=order.getObjectId();
					    		
					    		ParseQuery<ParseObject> query = ParseQuery.getQuery("lineProduct");
								query.whereEqualTo("order", order);
								
								
							     query.findInBackground(new FindCallback<ParseObject>() {
									    public void done(List<ParseObject> proList, ParseException e) {
									    	if (e==null){ 
								         	int j=proList.size();
								         	ParseObject proLine;
								         	int num=0;
								         	String name="";
								         	String msg="You purchase the following products:\r\n";
								         	double total=0;
								         	for(int i=0;i<j;i++)
								         	{
								         		proLine=proList.get(i);
								         		num=proLine.getInt("number");
								         		name=proLine.getString("proName");
								         		msg =msg + String.valueOf(num)+" "+name+"\r\n";
								         		total=total+proLine.getDouble("total");
								         	}
									    	 	
					    		            order.put("total",total);
					    		            order.saveInBackground();
					    		            
					    	                msg=msg+"Your total purchase is $"+String.valueOf(total); 
					    	                msg=msg+"\r\nAre you process this order? if Not, please press back.";
					    	                 
					    	                TextView Tvtxt = (TextView) findViewById(R.id.tvOrder);
					    	                Tvtxt.setText(msg);
									    	}
									    	
									    }
									      
									
							     });
								
					    	}	     
					    	else
					    	{
					    		// something went wrong
						    	Toast.makeText(OrderActivity.this, "fails", 50000).show();
						    	
					    	}
					    	
					    }
					    
					    
					    
					    
					
			});
				
			} else {
			  // show the signup or login screen	
			
			}
		
		
		  Button  btnOrder=(Button) findViewById(R.id.btnMakOrder);
		   
		   
		   btnOrder.setOnClickListener(new OnClickListener() {
	        	public void onClick(View arg0) {
	        		
	        		
	        		ParseUser currentUser = ParseUser.getCurrentUser();
	        		if (currentUser != null) {
	        		
	    			
	    			Intent i = new Intent(OrderActivity.this, ProcessActivity.class);
	    			
	    			startActivity(i);
	    			
	    		
	    			
	        		}
	        	}
	        });
		
	
		
		
	}
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.order, menu);
		return true;
	}

}
