package com.example.androidproject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.widget.RadioButton;
import android.widget.Toast;

public class SettingActivity extends Activity {
	
    private SharedPreferences sharedPrefs;
	 
	 private final int STANDARD_REQUEST_CODE = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
		
		 //so we can save/load data...
        sharedPrefs = getSharedPreferences("test_data", MODE_PRIVATE);
        
        RadioButton rad1= (RadioButton)findViewById(R.id.rad_red);
        RadioButton rad2= (RadioButton)findViewById(R.id.rad_blue);
        
        int color = sharedPrefs.getInt("color",1);
        

        if(color==-65536)
        {
        	rad1.setChecked(true);
        }
        
        if(color==-16776961)
        {
        	rad2.setChecked(true);
        }
        
        
      
        
	}
	
	
	  @Override
  	public void onBackPressed(){
		  
		//get the editor that lets us save data to our shared prefs object
			SharedPreferences.Editor editor = sharedPrefs.edit();
			
			  int color=0;
  	        RadioButton rad1= (RadioButton)findViewById(R.id.rad_red);
  	        RadioButton rad2= (RadioButton)findViewById(R.id.rad_blue);
  	        if(rad1.isChecked())
  	        {
  	       	 color= -65536;
  	       	 
  	        }
  	        
  	        if(rad2.isChecked())
  	        {
  	        	color= -16776961;
  	       	 
  	        }
  	        
  	      editor.putInt("color", color); 
  	      
  	    String msg;
		if(editor.commit())
			msg = "";
		else
		{
			msg = "Save failed!";
		Toast.makeText(SettingActivity.this, msg, 5000).show();
		}
		
		Intent iData = new Intent();
		iData.putExtra("color", color);
		

		//and send it back to the parent activity
		setResult(Activity.RESULT_OK, iData);
		  
      	finish();
      }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.setting, menu);
		return true;
	}

}
