package com.example.androidproject;


import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import android.content.SharedPreferences;
import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.GetDataCallback;
import com.parse.LogInCallback;
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import android.R.string;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class DisplayActivity extends Activity {
	
	
    ParseUser currentUser = ParseUser.getCurrentUser();
    SimpleAdapter sa;
    
  

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display);
		
		  Button btnY = (Button) findViewById(R.id.btn_YourOrder);
		  btnY.setOnClickListener(new OnClickListener() {
			  public void onClick(View v) {
				  
				// Open new activity...
			    	//1 - create an Intent which will be used to open DisplayMessageActivity
			    	Intent intent = new Intent(DisplayActivity.this, YOrdersActivity.class);
			    	//2 - store the text as a String..
			    	
			    	startActivity(intent);
			    	
	        	
				  
			  }
		  });
		
		  Button btnOrder = (Button) findViewById(R.id.btn_CheckOut);
		  btnOrder.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					
					
					
				ParseQuery<ParseObject> query = ParseQuery.getQuery("order");
				ParseUser currentUser= ParseUser.getCurrentUser();
				 query.whereEqualTo("parent", currentUser);
				 query.findInBackground(new FindCallback<ParseObject>() {
					    public void done(List<ParseObject> orderList, ParseException e) {
					    	if (e==null){
					    
					    	ParseObject order=orderList.get(0);
					      
					    	ParseQuery<ParseObject> query = ParseQuery.getQuery("lineProduct");
							query.whereEqualTo("order",order);
							query.findInBackground(new FindCallback<ParseObject>() {
							    public void done(List<ParseObject> prolist, ParseException e) {
							        if (e == null) {
							
					    	         if(prolist.isEmpty())
					    	         {
					    	        	 Toast.makeText(DisplayActivity.this, "Please order products, you don't order any product", 5000).show();
					    	         }
					    	         
					    	         else
					    	         {
					    	        	  
 
					    	        	 // Open new activity...
									    	//1 - create an Intent which will be used to open DisplayMessageActivity
									    	Intent intent = new Intent(DisplayActivity.this, OrderActivity.class);
									    	//2 - store the text as a String..
									    	
									    	startActivity(intent);
									    	
					    	        	
									    
					    	         }
					    	         
					                }
					              }
							        
					             });
							
							
							
					    }
				    	
					    }
					    
					    
					    
					    
					
			});
					 

					
					
				}
					
	        });
		
		
		
		ListView lv = (ListView) findViewById(R.id.custView);
			
		List<Map<String,String>> lm = convertData();
		
	
		

		
	   	
		 lv.setOnItemClickListener(new OnItemClickListener() {
	    	    public void onItemClick(AdapterView<?> parent,  final View view,
	    	         final int position, long id) {
                  
	    			ParseQuery<ParseObject> query = ParseQuery.getQuery("product");
	    			query.findInBackground(new FindCallback<ParseObject>() {
	    			     public void done(List<ParseObject> objects, ParseException e) {
	    			         if (e == null) {
	    			        	 ParseObject objProd=objects.get(position);
	    			        	 String objectId = objProd.getObjectId();
	    			        	 
	    			        	 startDetailActivity(view,objectId);
	    			        	 
	    			        	 
	    			         } else {
	    			        	 Toast.makeText(DisplayActivity.this, "error", 500000).show();
	    			         }
	    			     }
	    			 
	    			 });
	    	         
	    	    }

		
    	  });//end Listener*/
      
		 
		
		if (currentUser != null) {
		  // do stuff with the user;
			TextView tv_wel=(TextView) findViewById(R.id.Ds_Welcome);
			
			tv_wel.setText("Welcome "+currentUser.getUsername());
			

			                        ParseObject order = new ParseObject("order");
								    order.put("total", 0.00);
								    order.put("parent", currentUser);
								    order.saveInBackground();
				
			
		} else {
		  // show the signup or login screen	
		
		}
		
		
	
	}

	public List<Map<String, String>> convertData()
	{
		//create an instance of the List of HashMaps that you will return
		 final List<Map<String, String>> lm = new ArrayList<Map<String,String>>(); 
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery("product");
		query.findInBackground(new FindCallback<ParseObject>() {
		     public void done(List<ParseObject> objects, ParseException e) {
		         if (e == null) {
		        	 	 
		        	
		            for(int i=0;i<objects.size(); i++)
		            {
		            	ParseObject objProd=objects.get(i);
		            	
		            	//Create a new hashmap to add to you list
		    			Map<String,String> map = new HashMap<String,String>();
		            	map.put("Name", objProd.getString("Name"));
		            	
		            	map.put("price",String.valueOf(objProd.getDouble("price")));
		            	
		            	//add the hashmap to your list of hashmaps
		    			lm.add(map);
		            
		            
		            
		            
		            }
		            
		            
		        	//create a simple adapter
		   		 sa = new SimpleAdapter(
		   				DisplayActivity.this,										//the context
		   				lm,														//your list of hashmaps
		   				R.layout.cust_layout,								//a reference to your custom listview layout
		   				new String[] {"Name", "price"},				//the keys in your hashmap
		   				new int	[] {R.id.tvName, R.id.tvPrice}//the ids of the textview you will insert the data into
		   				);
		   		 
		   		
		 		ListView lv = (ListView) findViewById(R.id.custView);
		            
		   		lv.setAdapter(sa);
				 
			  	lv.setTextFilterEnabled(true);
		        	 
		         } else {
		        	 Toast.makeText(DisplayActivity.this, "error", 500000).show();
		         }
		     }
		 
		 });
		
	
		//return your list
		return lm;
	}
	
	public void startDetailActivity(View v,String strId) {
		
		Intent i = new Intent(DisplayActivity.this, DetailsActivity.class);
		//pass an string to other activity
		i.putExtra("proId",strId);
		
		startActivity(i);
		
	}
	
	
	@Override
	public void onBackPressed(){
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery("order");
		
		/*
		// Retrieve the object by id
		query.getInBackground(OrderId, new GetCallback<ParseObject>() {
		  public void done(ParseObject order, ParseException e) {
		    if (e == null) {
		    	
		    	  ParseQuery<ParseObject> query = ParseQuery.getQuery("lineProduct");
					query.whereEqualTo("order", order);
					query.findInBackground(new FindCallback<ParseObject>() {
					    public void done(List<ParseObject> proList, ParseException e) {
					    	if (e==null){
					    		
					    		int i=proList.size();
					    		
					    		for(int j=0;j<i;j++)
					    		{
					    		   ParseObject proLine=proList.get(j);
					    		   proLine.deleteInBackground();
					    		}
					    	}
					    	else
					    	{
					    	
					    	}
					    	
					    }
					
			});
		    	
		      order.deleteInBackground();
		    }
		  }
		});
         */
	
		// Open new activity...
    	//1 - create an Intent which will be used to open DisplayMessageActivity
    	Intent intent = new Intent(DisplayActivity.this, MainActivity.class);
    	//2 - store the text as a String..
    	
    	startActivity(intent);
		
		finish();
		
	}
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.display, menu);
		return true;
	}

}
