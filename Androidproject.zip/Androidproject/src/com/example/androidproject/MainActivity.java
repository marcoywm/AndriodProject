package com.example.androidproject;


import com.parse.LogInCallback;
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

import android.app.Activity;
import android.view.Menu;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	 private Button btnLoad, btnReg, btntest;
	  
     private SharedPreferences sharedPrefs;
	 
	 private final int STANDARD_REQUEST_CODE = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		 //so we can save/load data...
        sharedPrefs = getSharedPreferences("Load_data", MODE_PRIVATE);
		
		   Parse.initialize(this, "TGou45X9z1x4wKMgHRjUkXd8Q5hUVE8Ce6gIKDsP",
				   "3VqBJXGXRi6LDOp2qc0Ig3TwskQzkvsCW3nNNiBb"); 
		   
		   ParseAnalytics.trackAppOpened(getIntent());
		   //ParseObject testObject = new ParseObject("TestObject");
		   //testObject.put("foo", "bar");
		   //testObject.saveInBackground();
		   
		 btnReg=(Button)findViewById(R.id.btn_Reg);
		 
		 btnReg.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					
					  // Open new activity...
			    	//1 - create an Intent which will be used to open DisplayMessageActivity
			    	Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
			    	//2 - store the text as a String..
			 
			    	startActivityForResult(intent, STANDARD_REQUEST_CODE);
				}
					
	        });
		 
		 btnLoad=(Button)findViewById(R.id.btn_Login);
		 btnLoad.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					EditText tv_name = (EditText) findViewById(R.id.tv_Name);
					EditText tv_password = (EditText) findViewById(R.id.tv_Pass);
					
					String name=tv_name.getText().toString();
					String password=tv_password.getText().toString();
					
					

					try {
						ParseUser.logIn(name, password);
						  // Open new activity...
				    	//1 - create an Intent which will be used to open DisplayMessageActivity
				    	Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
				    	//2 - store the text as a String..
				    	
				    	startActivity(intent);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						Toast.makeText(MainActivity.this, "login Fail, please register", 50000).show();
					}
					
				
				}
					
	        });
		 

	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == STANDARD_REQUEST_CODE) {
			if(resultCode == RESULT_OK) {
				//we should have data in the intent
				String name = data.getStringExtra("name");
				
				String password = data.getStringExtra("password");
				
				//2 - get a reference to the EditText object in this activity
		    	EditText nameText = (EditText)findViewById(R.id.tv_Name);
		    	//set the result
		    	nameText.setText(name);
		    	
		    	//2 - get a reference to the EditText object in this activity
		    	EditText passText = (EditText)findViewById(R.id.tv_Pass);
		    	//set the result
		    	passText.setText(password);
		    	
		    	
				
		    	
			}
			else if(resultCode == RESULT_CANCELED) {
				//no data :(
				 Toast.makeText(this, "No data!", Toast.LENGTH_LONG).show();
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
