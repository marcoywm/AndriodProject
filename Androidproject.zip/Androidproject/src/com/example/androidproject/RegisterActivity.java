package com.example.androidproject;

import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import android.R.string;
import android.net.ParseException;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class RegisterActivity extends Activity {
	
	 private Button  btnLoad;
	 private EditText etMessage;
	  
	 private SharedPreferences sharedPrefs;
	 
	 private final int STANDARD_REQUEST_CODE = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		
		//so we can save/load data...
        sharedPrefs = getSharedPreferences("test_data", MODE_PRIVATE);
        
        //load the data
        btnLoad = (Button)findViewById(R.id.btn_Regs);
        //start TestActivity for result when the button is clicked
        btnLoad.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				
				//get the editor that lets us save data to our shared prefs object
				SharedPreferences.Editor editor = sharedPrefs.edit();
				
				//get values from shared preferences object and display
				//String name = sharedPrefs.getString("name", "Mr");
				//String age = sharedPrefs.getString("age", "1");
				EditText tv_name = (EditText) findViewById(R.id.tv_userName);
				EditText tv_password = (EditText) findViewById(R.id.tv_password);
				EditText tv_email = (EditText) findViewById(R.id.tv_Email);
				final EditText tv_fullname = (EditText) findViewById(R.id.tv_FullName);
				
			 String name=tv_name.getText().toString();
			 String password=tv_password.getText().toString();
			 String email=tv_email.getText().toString();
			 String fullname=tv_fullname.getText().toString();
			 
			 ParseUser user = new ParseUser();
			 user.setUsername(name);
			 user.setPassword(password);
			 user.setEmail(email);
			 user.put("fullname", fullname);
			 
			 
			 
			try
			{
				user.signUp();
				
				//write values
				editor.putString("name", name);
				editor.putString("password", password);
				
				String msg;
				if(editor.commit())
				{}
				else
				{
					msg = "Save failed!";
				Toast.makeText(RegisterActivity.this, msg, 5000).show();
				}
				if (name == null || name.equals("")||password == null || password.equals("")) {
					//if no data to return...
					setResult(Activity.RESULT_CANCELED);
					finish();
				} else {
					//yay, data!		
					//put it into an intent				
					Intent iData = new Intent();
					iData.putExtra("name", name);
					iData.putExtra("password", password);
					//and send it back to the parent activity
					setResult(Activity.RESULT_OK, iData);
					finish();
				
				}
				
			}
			catch (com.parse.ParseException e) {
				// TODO Auto-generated catch block
				Toast.makeText(RegisterActivity.this, e.toString(), 5000).show();
			}
			 
			 

				
			}
        });    
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

}
