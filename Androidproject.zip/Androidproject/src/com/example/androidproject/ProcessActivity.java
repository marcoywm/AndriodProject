package com.example.androidproject;

import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ProcessActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_process);
		
		ParseUser currentUser = ParseUser.getCurrentUser();
		if (currentUser != null) {
		  // do stuff with the user;
			TextView tv_wel=(TextView) findViewById(R.id.tvProWel);
			
			tv_wel.setText("Welcome "+currentUser.getUsername());
			
			 
			Button btnLoad=(Button)findViewById(R.id.btn_shop);
			 btnLoad.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						Intent i = new Intent(ProcessActivity.this, DisplayActivity.class);
						
						startActivity(i);
						
						}
						
					
					
						
		        });
			
	          }
	         
			
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.process, menu);
		return true;
	}

}
