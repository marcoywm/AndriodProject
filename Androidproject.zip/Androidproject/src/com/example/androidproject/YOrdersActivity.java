package com.example.androidproject;

import java.util.List;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class YOrdersActivity extends Activity {
	
	
	
	private SharedPreferences sharedPrefs;
	 
	 private final int STANDARD_REQUEST_CODE = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_yorders);
		
		 
		
		ParseUser currentUser= ParseUser.getCurrentUser();
		
		if (currentUser != null) {
			TextView tv_wel=(TextView) findViewById(R.id.tv_YWel);
			
			tv_wel.setText("Welcome "+currentUser.getUsername());
			
			ParseQuery<ParseObject> query = ParseQuery.getQuery("order");
		    query.whereEqualTo("parent", currentUser);
		    query.findInBackground(new FindCallback<ParseObject>() {
			    public void done(List<ParseObject> orderList, ParseException e) {
			    	if (e==null){
			    		int i=orderList.size();
			    		String msg="You Orders is following:\r\n";
			    		ParseObject order;
			    		double total=0;
			    		int k=1;
			    		for(int j=0;j<i;j++)
			    		{
			    			order=orderList.get(j);
			    			total=order.getDouble("total");
			    			
			    			
			    			if (total>0)
			    			{
			    				
			                    msg=msg+"order "+ String.valueOf(k)+"\r\n";
			    				msg=msg+"Create at "+ order.getCreatedAt();
			    				msg=msg+" total price purchase is $"+order.getDouble("total")+"\r\n";
			    				k++;
			    			}
			    		}
			    		
			    		
			    		
			    		
			    		TextView tv_wel=(TextView) findViewById(R.id.tv_YOrders);
						
						tv_wel.setText(msg);
			    	}
			    	
			    }
			    
			    
			    
			    
			
	});
		
	       
			
		
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.layout.menu, menu);
    	return super.onCreateOptionsMenu(menu);
		
	}
	
	//menu setting
		 @Override
		    public boolean onOptionsItemSelected(MenuItem item) {
		    	switch (item.getItemId()) {
		    	case R.id.refresh:
		    		
		    		Intent intent = new Intent(YOrdersActivity.this, SettingActivity.class);
			    	//2 - store the text as a String..
			 
		    		startActivityForResult(intent, STANDARD_REQUEST_CODE);
		    	
		    		break;
		    	}
		    	
		    	
		    	return true;
		    }
		 
		 
		 protected void onActivityResult(int requestCode, int resultCode, Intent data) {
				// TODO Auto-generated method stub
				super.onActivityResult(requestCode, resultCode, data);
				if(requestCode == STANDARD_REQUEST_CODE) {
						//we should have data in the intent
					
					int color=data.getIntExtra("color", 0);
					
					
						
					TextView tvLabel = (TextView)findViewById(R.id.tv_YOrders);
					//setting
					
			
					tvLabel.setTextColor(color);
				
					
					 
					}
					else if(resultCode == RESULT_CANCELED) {
						
					}
				}

}
